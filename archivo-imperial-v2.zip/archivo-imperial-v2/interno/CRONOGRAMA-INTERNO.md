# Cronograma interno de producción — primer ciclo de 14 días

**Documento de administración. No publicar en GitHub Pages.** La agenda pública presenta las ocasiones narrativas; este documento reserva el giro o acontecimiento que la administración debe preparar.

| Día | Convocatoria pública | Preparación interna / acontecimiento | Material que debe preparar administración |
|---|---|---|---|
| 01 | Apertura del registro de casas | Publicación de reglas, apertura de fichas y comprobación de procedencias | Lista de personajes, ramas y responsables familiares |
| 02 | Audiencia de primavera | La soberana recibe a representantes; se presentan tensiones menores entre casas | Edicto de apertura y orden de precedencia |
| 03 | Jornada de jardines y té | Primera reunión social; dejar circular un rumor menor sobre una alianza comercial | Invitación y rumor inicial no vinculante |
| 04 | Ejercicios de estrategia | Competencias de arquería, pitch-pot, weiqi y billar; registrar resultados narrativos | Reglas breves de cada juego y tabla de resultados |
| 05 | Edicto sobre abastecimiento | Problema de suministro de grano o sal en una ruta secundaria; no anunciar todavía la causa | Edicto, mapa simple y datos para las casas mercantiles y de hacienda |
| 06 | Banquete de las casas | Familia anfitriona elegida mediante ruleta; durante la reunión se descubre una discrepancia en los registros de carga | Ruleta, invitación y pista documental |
| 07 | Jornada de correspondencia | Día libre para que los personajes intercambien cartas y desarrollen consecuencias del banquete | Ningún evento obligatorio |
| 08 | Noticias del camino oriental | Confirmar que el daño en la ruta fue provocado por una crecida, aunque hay versiones contradictorias | Informe de viajeros y dos testimonios incompatibles |
| 09 | Consulta del templo | El abad interpreta el incidente como mal presagio; mantener ambigüedad entre superstición y explicación práctica | Texto ceremonial y presagio abierto |
| 10 | Exhibición de manuscritos y arte | Presentar la obra de un artista aspirante; la casa imperial manifiesta interés, sin nombrarlo todavía artista predilecto | Catálogo de exhibición y pieza destacada |
| 11 | Subasta de piezas históricas | Primera subasta: recetario del Valle, libro de autor apreciado por la familia imperial, pintura de las cuatro estaciones y sello antiguo | Catálogo, orden de lotes, valores de salida y registro de adjudicaciones |
| 12 | Consejo de defensa | El General en Jefe informa que la ruta oriental necesita protección; abrir discusión sobre escoltas y gasto | Informe militar y posibles respuestas |
| 13 | Fiesta de té de la capital | Segunda anfitriona elegida mediante ruleta; una cortesana escucha una conversación sobre la carga desaparecida | Invitación, personaje informante y pista parcial |
| 14 | Cierre del primer ciclo | Publicar consecuencias, validar puntos, descontar faltas de decoro si corresponde y abrir el siguiente ciclo | Tabla validada de méritos y resumen de continuidad |

## Control de continuidad

- No otorgar puntos por inscripción, parentesco, presencia pasiva o mera asistencia.
- Toda puntuación debe asociarse a una escena o contribución comprobable.
- Las deducciones por decoro deben estar justificadas, ser proporcionales y revisarse antes de publicarse.
- La anfitriona de cada banquete o fiesta de té se elige mediante ruleta; no repetir familia de manera consecutiva salvo que la participación lo justifique.
- La historia de la carga oriental debe avanzar por pistas; no revelar la causa completa en el primer evento.
- Los lotes de la subasta inaugural son históricos y narrativamente útiles; sus precios deben fijarse según el saldo inicial familiar que se acuerde.
