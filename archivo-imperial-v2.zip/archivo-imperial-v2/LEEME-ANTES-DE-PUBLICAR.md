# ARCHIVO IMPERIAL — VERSIÓN 2

Esta entrega contiene tres materiales:

1. `web/`: sitio informativo para GitHub Pages.
2. `Guia-de-bienvenida-lobby.pptx`: presentación para compartir en el lobby antes de elegir personaje.
3. `interno/CRONOGRAMA-INTERNO.md`: planificación reservada para administración, con los acontecimientos concretos de las primeras dos semanas.

## Publicación correcta

Sube únicamente el contenido de la carpeta `web/` a la raíz del repositorio de GitHub Pages. No subas la carpeta `interno/` al repositorio público; contiene la planificación de sucesos que debe permanecer en administración.

La presentación puede compartirse como archivo en el lobby. El cronograma interno debe permanecer separado de los materiales públicos.

## Decisiones reflejadas

- No hay emperador ni emperatriz viuda en el presente; Otoha es la soberana.
- La sucesión futura puede considerar a los hijos de Otoha, Osamu y Atsumu, mediante méritos.
- Ejército reducido a Ministro de Guerra, General en Jefe, Guardia Imperial, soldados y cadetes.
- Templo budista con un solo Abad; Valle de la Medicina con un Maestro y un Aprendiz.
- Las cortesanas trabajan fuera del palacio, en casas de té y jardines privados, con dos funciones.
- Se elimina el mercado, las solicitudes, los formularios y las cuentas individuales.
- La web es informativa; el inventario y el registro de puntos son apartados de consulta.
- Una cuenta bancaria por familia y una entrada semanal; las cantidades quedan pendientes de fijación.
- Subastas históricas, no mercado general.
- La paleta se adapta automáticamente a la preferencia de tema claro u oscuro del dispositivo.
- El contenido está separado en módulos editables dentro de `web/js/data/`.

## Pendientes que deliberadamente no se inventaron

- Nombres definitivos de las familias y sus ramas.
- Saldo inicial de cada cuenta familiar y cuantía de la entrada semanal.
- Titularidad y patronazgo de las casas de té de la capital.
- Valores de salida definitivos de los lotes de subasta.
- Registro real de personajes y puntajes, que se incorporará cuando exista información validada.
