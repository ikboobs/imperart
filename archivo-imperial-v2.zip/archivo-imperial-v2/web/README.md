# Archivo de la Dinastía — V2

Sitio informativo estático para GitHub Pages. Esta versión no contiene formularios, solicitudes, banco operativo, mercado ni herramientas de edición desde la interfaz.

## Publicar en GitHub Pages

1. Extrae el ZIP.
2. Abre la carpeta `web`.
3. Sube **el contenido de `web`** a la raíz del repositorio (no la carpeta `web` como subcarpeta, salvo que configures Pages para esa ruta).
4. En GitHub entra a **Settings → Pages**.
5. Selecciona **Deploy from a branch**, rama `main` y carpeta `/ (root)`.
6. Guarda los cambios.

## Edición modular

El contenido está separado de la estructura y los estilos:

- `js/data/dinastia.js`: historia dinástica y procedencias generales.
- `js/data/instituciones.js`: cargos, templo, medicina, obediencias y vías de influencia femenina.
- `js/data/meritos.js`: tipos de puntos, escalafón y normas de decoro.
- `js/data/economia.js`: inventarios por familia y catálogo de subasta.
- `js/data/agenda.js`: agenda pública de dos semanas.
- `js/data/familias.js`: registro de familias, integrantes y puntajes publicados.
- `js/app.js`: montaje de los módulos en la página.
- `styles.css`: identidad visual y adaptación automática al tema claro/oscuro del dispositivo.

Para agregar una familia, edita `familyStandings` en `js/data/familias.js` con esta estructura:

```js
export const familyStandings = [
  {
    name: 'Nombre de la familia',
    points: 0,
    members: [
      { name: 'Nombre del personaje', points: 0 }
    ]
  }
];
```

Los puntos deben ser los validados por la administración; no se asignan valores automáticos.

## Importante

GitHub Pages publica archivos estáticos. Los registros editados en el código son visibles al volver a publicar, pero no se sincronizan por sí solos entre usuarios. El banco, las cuentas familiares, las subastas con pujas en tiempo real y la edición multiusuario requieren una base de datos y autenticación externas; se dejan fuera de esta entrega porque se decidió que la web sea informativa.
